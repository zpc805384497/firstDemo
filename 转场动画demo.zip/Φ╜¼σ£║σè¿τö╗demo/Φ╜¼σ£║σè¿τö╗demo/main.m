//
//  main.m
//  转场动画demo
//
//  Created by zhishun on 2016/11/16.
//  Copyright © 2016年 zhishun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
