//
//  SecondVC.h
//  转场动画demo
//
//  Created by zhishun on 2016/11/16.
//  Copyright © 2016年 zhishun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondVC : UIViewController

@end
