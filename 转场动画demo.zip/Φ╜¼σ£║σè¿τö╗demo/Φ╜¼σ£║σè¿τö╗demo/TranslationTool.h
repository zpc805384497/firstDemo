//
//  TranslationTool.h
//  转场动画demo
//
//  Created by zhishun on 2016/11/16.
//  Copyright © 2016年 zhishun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger,XWPresentOneTransitionType) {
    XWPresentOneTransitionTypePresent = 0,//管理present动画
    XWPresentOneTransitionTypeDismiss =1,//管理dismiss动画
    XMPushOneTransitionTypePush = 2,
    XMPopOneTransitionTypePush = 3
};
@interface TranslationTool : NSObject<UIViewControllerAnimatedTransitioning>


+ (instancetype)translationWithTransitionType:(XWPresentOneTransitionType)transitionType;

- (instancetype)initWithTransitionType:(XWPresentOneTransitionType)transitionType;
@end
