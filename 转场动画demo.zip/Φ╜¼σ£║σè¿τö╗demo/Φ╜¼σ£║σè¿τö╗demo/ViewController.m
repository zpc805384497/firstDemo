//
//  ViewController.m
//  转场动画demo
//
//  Created by zhishun on 2016/11/16.
//  Copyright © 2016年 zhishun. All rights reserved.
//

#import "ViewController.h"
#import "SecondVC.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
}
- (IBAction)buttonClick:(UIButton *)sender {
    NSMutableArray *numberList = [[NSMutableArray alloc] initWithObjects:@2,@9,@29,@89,@76,@8,@4,@38,@98,@54,@34,@89, nil];
    
    NSNumber *temp = nil;
//    for (int i=0; i<numberList.count-1; i++) {
//        for (int j = 0; j<numberList.count-1-i;j++) {
//            if (numberList[j] > numberList[j+1]) {
//                temp = numberList[j];
//                numberList[j] = numberList[j+1];
//                numberList[j+1] = temp;
//            }
//        }
//    }
//    NSLog(@"--------numberList---------%@",numberList);
    
    BOOL flag = true;
    for (int i=0; i<numberList.count-1; i++) {
        flag = false;
        for (int j=0; j<numberList.count-1-i; j++) {
            if (numberList[j] > numberList[j+1]) {
                temp = numberList[j];
                numberList[j] = numberList[j+1];
                numberList[j+1] = temp;
                flag = true;
            }
        }
        if (!flag) {
            break;
        }
    }
     NSLog(@"--------numberList---------%@",numberList);
    
//    SecondVC *vc = [[SecondVC alloc] init];
//    [self presentViewController:vc animated:YES completion:nil];
}
- (IBAction)btnClick:(UIButton *)sender {
    
        NSMutableArray *numberList = [[NSMutableArray alloc] initWithObjects:@2,@9,@29,@89,@76,@8,@4,@38,@98,@54,@34,@89, nil];
        NSNumber *temp = nil;
        for (int i=0; i<numberList.count-1; i++) {
            for (int j = 0; j<numberList.count-1-i;j++) {
                if (numberList[j] > numberList[j+1]) {
                    temp = numberList[j];
                    numberList[j] = numberList[j+1];
                    numberList[j+1] = temp;
                }
            }
        }
        NSLog(@"--------numberList---------%@",numberList);
}
- (CGRect)buttonFrame{
    return self.button.frame;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
