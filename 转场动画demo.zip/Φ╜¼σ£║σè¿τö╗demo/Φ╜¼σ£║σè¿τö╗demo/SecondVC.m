//
//  SecondVC.m
//  转场动画demo
//
//  Created by zhishun on 2016/11/16.
//  Copyright © 2016年 zhishun. All rights reserved.
//

#import "SecondVC.h"
#import "TranslationTool.h"

@interface SecondVC ()<UIViewControllerTransitioningDelegate>
@property (strong, nonatomic) IBOutlet UIButton *button;
@property (nonatomic,strong) TranslationTool* tranlasition;
@end

@implementation SecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (instancetype)init
{
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}
- (IBAction)buttonClick:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [TranslationTool translationWithTransitionType:XWPresentOneTransitionTypePresent];
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return [TranslationTool translationWithTransitionType:XWPresentOneTransitionTypeDismiss];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
